var Person = function(first, last){
this.fisrtName = first,
this.lasttName = last,
this.printName = function(){
		console.log(`${this.firstName} ${this.lastName}`);
}
}

var john = new Person('John', 'Don');
john.printName(this);

function checkThis(){
    
}