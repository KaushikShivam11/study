var budgetController = (function(){
    
    // creating the expense constructor
    var Expense = function(id, description, value){
        this.id = id;
        this.description = description;
        this.value = value ;
        this.percentage = -1;
    };
    
    //adding a prototype function
    Expense.prototype.calPercent = function(totalIncome){
        if(totalIncome > 0){
           this.percentage = Math.round((this.value/totalIncome)*100);
           }
        else{
            this.percentage = -1;
        }
    };  
    
    // creating the income constructor
    var Income = function(id, description, value){
        this.id = id;
        this.description = description;
        this.value = value ;
    };
    
    // calculate the totals
    var calculateTotals = function(type){
         var sum = 0;
                data.allItems[type].forEach(function(cur){
                sum += cur.value;
                });
            data.totals[type] = sum; 
            data.budget = data.totals.inc - data.totals.exp;
            data.percentage = Math.round((data.totals.exp/data.totals.inc)*100);
        
    };
    
    // data structure of te application
    var data = {
        
        allItems :{
            exp : [],
            inc : []
        },
        
        totals :{
            exp : 0,
            inc : 0
        },
        
        budget : 0,
        
        percentage : -1
    };
    
    // public function that returns new item function either inc or exp
    return {
        addItem : function(type, des, val){            
            var newItem, ID;
            if(data.allItems[type].length > 0){
                ID = data.allItems[type][data.allItems[type].length -1].id + 1;
               }
            else{
                ID = 0;
              }      
            
            if (type === 'exp'){
                    newItem = new Expense(ID, des, val);
                    newItem.calPercent(data.totals.inc);
                } 
            else {
                    newItem = new Income(ID, des, val);
            }
             
            data.allItems[type].push(newItem);
            return newItem;
        },
        
        deleteItem : function(type, ID){
            var ids, index;
            ids = data.allItems[type].map(function(cur){
                return cur.id;
            });
            index = ids.indexOf(ID);
            if (index !== -1){
            data.allItems[type].splice(index,1);
            }
        },
        
        calculateBudget: function(type){
            calculateTotals(type);
        },
        
        returnBudget: function(){
            return {
                Budget : data.budget,
                income : data.totals.inc,
                expenses: data.totals.exp,
                percentage : data.percentage
            }
        },
        
        testing : function(){
            console.log(data);
        }
    }
    
})();


// UI controller
var UIController = (function(){
    
     // making te single place of all the DOM string
    var domStrings = {
         
                inputType : '.add__type',
                inputDescription : '.add__description',
                value : '.add__value',
                inputBtn : '.add__btn',
                incomeContainer : '.income__list',
                expensesContainer : '.expenses__list',
                budgetLabel : '.budget__value',
                incomeLabel : '.budget__income--value',
                expenseLabel : '.budget__expenses--value',
                percentageLabel : '.budget__expenses--percentage',
                container : '.container',
                monthLabel : '.budget__title--month'
        
    };
    
    // Reading the input data thru a public func 
    return {
        getInput : function(){
                        var inputValues =   {
                                            inputType : document.querySelector(domStrings.inputType).value,
                                            inputDescription : document.querySelector(domStrings.inputDescription).value,
                                            value : parseFloat(document.querySelector(domStrings.value).value)
                                            } ;  
                        return inputValues;
        },
        domStrg : domStrings,
        
        // adding new Item on UI in the Expense list or Income List  
        addNewUiItem : function(obj, type){
            
            //getting Dom String from HTML and replacing the placeholders with actual Data
            var html, newHtml, element;
            
            if (type === 'inc'){
                    element = domStrings.incomeContainer;
                    html = '<div class="item clearfix" id="inc-%id%"><div class="item__description">%desc%</div><div class="right clearfix"><div class="item__value">%val%</div><div class="item__delete"><button class="item__delete--btn"><i class="ion-ios-close-outline"></i></button></div></div></div>'
                }
            else if (type === 'exp'){
                    element = domStrings.expensesContainer;
                    html = '<div class="item clearfix" id="exp-%id%"><div class="item__description">%desc%</div><div class="right clearfix"><div class="item__value">%val%</div><div class="item__percentage">%itempercent%</div><div class="item__delete"><button class="item__delete--btn"><i class="ion-ios-close-outline"></i></button></div></div></div>'   
                }      
            newHtml = html.replace('%id%', obj.id);
            newHtml = newHtml.replace('%desc%', obj.description);
            newHtml = newHtml.replace('%val%', obj.value);
            
            if(type === 'exp'){
               newHtml = newHtml.replace('%itempercent%', obj.percentage + '%');
               }
            
            // Insert the newHtml to DOM 
            document.querySelector(element).insertAdjacentHTML('beforeend', newHtml);
        },
        
        //deleting items from UI in exp list of inc list
        deleteUiItem : function(parentID){
            var oChild = document.getElementById(parentID);
            oChild.parentNode.removeChild(oChild);
        },
        
        // clears the input field 
        clearFields : function(){
            var fields, aFields;        
            fields = document.querySelectorAll(domStrings.inputDescription + ', ' + domStrings.value);
            aFields = Array.prototype.slice.call(fields);
            aFields.forEach(function(current, index, arr){
               current.value = ""; 
            });
            aFields[0].focus();            
        },
        
        displayBudget: function(obj){
            document.querySelector(domStrings.budgetLabel).textContent = obj.Budget;
            document.querySelector(domStrings.incomeLabel).textContent = obj.income;
            document.querySelector(domStrings.expenseLabel).textContent = obj.expenses;
            
            if (obj.percentage > 0){
                document.querySelector(domStrings.percentageLabel).textContent = obj.percentage + '%';
                }
            else{
                document.querySelector(domStrings.percentageLabel).textContent = '--';
            }
            
        },
        getDate : function(){
            var month, year, now, months;
                months = ['Jan', 'Feb', 'Mar', 'Apr', 'May',
                         'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                now = new Date();
                year = now.getFullYear();
                month = months[now.getMonth()];
                document.querySelector(domStrings.monthLabel).textContent = month + ' ' + year;
        
        }
        
    }
    
})();


// app controller 
var controller = (function(budgetCtrl, UICtrl){
    // setting up all the events on the central Place
    var setUpEvents = function(){
        var DOM = UICtrl.domStrg;
        document.querySelector(DOM.inputBtn).addEventListener('click', ctrlAddItem);
        document.addEventListener('keypress', function(event) {
            if (event.keyCode === 13 || event.which === 13) {
                ctrlAddItem();
            }
        });
        
        // adding listen for item Delete
        document.querySelector(DOM.container).addEventListener('click', ctrlDeleteItem);
        
    };
    
    //calculate and update budget
    function calcBudget(type){
        // Calculate the Budget
        budgetCtrl.calculateBudget(type);
        
        // getting the budget from the budget controller 
        var budget = budgetCtrl.returnBudget();
        
        // Display the budget on the UI
        
        UICtrl.displayBudget(budget);
    }   
    
    // Percentage on each list item
    function calculatePercentage(){
        //calculate Percentage
            
        //Read percentage from Budget Controller
        
        //Update the UI with new Percentage
    }
    
    // event fired on btn press to add item
    function ctrlAddItem(e){
        // get the input Fields
        var values = UICtrl.getInput();
        
        //Only if there is appropriate data in the input fields
        if (values.inputDescription !== "" && !isNaN(values.value) && values.value > 0){
            
            // add the item to the budget Controller
            var newItemObject = budgetCtrl.addItem(values.inputType, values.inputDescription, values.value);

            // add the new item to the UI 
            UICtrl.addNewUiItem(newItemObject, values.inputType);

            // clear the fields
            UICtrl.clearFields();

            // cal and upadte Budget
            calcBudget(values.inputType);
            
            // call Update Percentage on addition of new Item
            calculatePercentage();
        }        
    }
    
    function ctrlDeleteItem(e){
        var itemID , splitID, type, ID;
        
        itemID =  e.target.parentNode.parentNode.parentNode.parentNode.id; 
        if (itemID){
                splitID = itemID.split('-');
                type = splitID[0];
                ID = parseInt(splitID[1]);
            }
        budgetCtrl.deleteItem(type, ID);
        UICtrl.deleteUiItem(itemID);
        calcBudget(type);
        
    }
    
    return {
        // initialization of the App 
        init : function(){
            UICtrl.displayBudget({
                Budget : 0,
                income : 0,
                expenses: 0,
                percentage : -1
            });
            setUpEvents();
            
            UICtrl.getDate();
        }
    }
    
})(budgetController, UIController);

// only place from where the app starts
controller.init();